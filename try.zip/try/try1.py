from flask import *
from flask_cqlalchemy import CQLAlchemy

app = Flask(__name__)
app.config['CASSANDRA_HOSTS'] = ['127.0.0.1']
app.config['CASSANDRA_KEYSPACE'] = "emp"

db = CQLAlchemy(app)

class Student(db.Model):
    uid = db.columns.Integer(primary_key=True)
    username = db.columns.Text(required=True)
    password = db.columns.Text()
    
      # shows welcome page
    @app.route('/')
    def show_index():
        return render_template('index.html')

      # adds new student
    @app.route('/add', methods = ['POST', 'GET'])
    def add():
        if request.method == 'POST':
            if not request.form['uid'] or not request.form['username'] or not request.form['password']:
                flash('Please enter all the fields', 'error')
            else:
                stud = Student.create(uid=request.form['uid'], username=request.form['username'], password=request.form['password'])
                stud.save()
                return render_template("successful.html")
        else:
            abort(401)

      # shows student list
    @app.route('/students')
    def show_list():
        ob = Student.objects.all()
        return render_template('list.html', ls = ob)

      # delets student
    @app.route('/showdelete')
    def show_delete():
        return render_template('delete.html')

    @app.route('/delete', methods = ['POST', 'GET'])
    def delete_student():
        if request.method == 'POST':
            uid = int(request.form['id'])
            stud = Student.objects(uid=uid).delete()
            return render_template('successful.html')

      # updates students
    @app.route('/showupdate')
    def show_update():
        return render_template('update.html')    

    @app.route('/update', methods = ['POST', 'GET'])
    def update_student():
        if request.method == 'POST':
            uid=int(request.form['id'])
            username=request.form['username']
            Student.objects(uid=uid).update(username=username)
            return render_template('successful.html')
    
db.sync_db()
if __name__ == '__main__':
    app.run(debug = True)
